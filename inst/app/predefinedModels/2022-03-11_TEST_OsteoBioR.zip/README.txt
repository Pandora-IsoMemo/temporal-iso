test model down/upload
