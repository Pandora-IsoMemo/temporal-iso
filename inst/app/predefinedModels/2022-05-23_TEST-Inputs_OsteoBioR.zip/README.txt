test: only data and model inputs
